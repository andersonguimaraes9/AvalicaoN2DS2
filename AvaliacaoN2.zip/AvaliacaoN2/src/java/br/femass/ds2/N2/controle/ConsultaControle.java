/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.femass.ds2.N2.controle;

import br.femass.ds2.N2.dao.ConsultaDAO;
import br.femass.ds2.N2.modelo.Paciente;
import br.femass.ds2.N2.modelo.Consulta;
import java.util.List;

/**
 *
 * @author Anderson Guimaraes
 */
public class ConsultaControle {
    private ConsultaDAO dao;
    
    public ConsultaControle(){
        this.dao= new ConsultaDAO();
    }
    
     public void cadastar(Consulta e){
        if(this.dao == null){
            this.dao= new ConsultaDAO();
        }
        this.dao.cadastrar(e);     
    }
     
     public List listaEquipAlien(){ 
          if(this.dao == null){
            this.dao= new ConsultaDAO();
          }
        return this.dao.listar();
     }
    
     public void AtualizarEquipamento(Consulta e){
        if(this.dao == null){
            this.dao= new ConsultaDAO();
        }
        Paciente eq= new Paciente();
       
        this.dao.atulizarEquipamento(e);     
    }
     
    public void Excluir(Consulta e){
        if(this.dao == null){
            this.dao= new ConsultaDAO();
        }
        this.dao.excluir(e);     
    }
     public Object ListaPorID(Long id){
        if(this.dao == null){
            this.dao= new ConsultaDAO();
        }
        return this.dao.listarPorID(id);    
    }
}
