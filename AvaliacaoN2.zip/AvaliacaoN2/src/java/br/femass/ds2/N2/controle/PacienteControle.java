
package br.femass.ds2.N2.controle;

import br.femass.ds2.N2.dao.PacienteDAO;
import br.femass.ds2.N2.modelo.Paciente;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import javax.swing.JFileChooser;

public class PacienteControle {
    private PacienteDAO dao;
    
   
    public PacienteControle(){
        this.dao= new PacienteDAO();       
    }
    public void cadastar(Paciente c){
        if(this.dao == null){
            this.dao= new PacienteDAO();
        }
        this.dao.cadastrar(c);     
    } 
    public List ListarPaciente(){ 
          if(this.dao == null){
            this.dao= new PacienteDAO();
          }
        return this.dao.listar();
     }
    public void ExcluirEquipamentos(Paciente c){
        if(this.dao == null){
            this.dao= new PacienteDAO();
        }
        this.dao.excluir(c);   
    }
    
    public void AtualizarEquipamento(Paciente c){
        if(this.dao == null){
            this.dao= new PacienteDAO();
        }
        this.dao.alterar(c);      
    }
    
    public Object ListaPorID(Long id){
        if(this.dao == null){
            this.dao= new PacienteDAO();
        }
        return this.dao.listarPorID(id);    
    }
    
     public List ListaPorFabricante(String fabricante){
        if(this.dao == null){
            this.dao= new PacienteDAO();
        }
        return this.dao.listarPorFabricante(fabricante);    
    }
     
   
    
}
