
package br.femass.ds2.N2.dao;

//import java.sql.Connection;

import br.femass.ds2.N2.modelo.Paciente;
import br.femass.ds2.N2.modelo.Consulta;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;

//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;
//import java.util.ArrayList;
//import java.util.List;


public class ConsultaDAO implements IDAO{
   
    
      
     
        @Override
        public void cadastrar(Object o) {
            Consulta ea = (Consulta) o;
            
            EntityManagerFactory emf= br.femass.ds2.N2.dao.FabricaConexao.getConexao();
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            em.persist(ea);
            em.getTransaction().commit();
            em.close();      
        }
       
        @Override
        public List listar() {
            EntityManagerFactory emf= br.femass.ds2.N2.dao.FabricaConexao.getConexao();
            EntityManager em = emf.createEntityManager();
            TypedQuery<Consulta> query = em.createQuery("SELECT ea FROM Equipamentos_Alienados ea",Consulta.class);
            List<Consulta> lista = query.getResultList();
            em.close();
            emf.close();
            return lista;
        }
        
        public void atulizarEquipamento(Object o) {
        Consulta c = (Consulta) o;
         EntityManagerFactory emf= br.femass.ds2.N2.dao.FabricaConexao.getConexao();        
        EntityManager em = emf.createEntityManager();
        Consulta cAux = em.find(Consulta.class, c.getId());
        if(cAux==null){
            try {            
                throw new Exception("Equipamento não existe mais!");
            } catch (Exception ex) {
                Logger.getLogger(br.femass.ds2.N2.dao.ConsultaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        em.getTransaction().begin();
        em.merge(c);
        em.getTransaction().commit();
        em.close();
        }

    @Override
    public void alterar(Object o) {
        throw new UnsupportedOperationException("Nao implementado por questão de regra de negocio"); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void excluir(Object o) {
        Consulta c = (Consulta) o;
        EntityManagerFactory emf= br.femass.ds2.N2.dao.FabricaConexao.getConexao();
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        c = em.find(Consulta.class, c.getId());
        em.remove(c);
        em.getTransaction().commit();
        em.close();
    }
    public Object listarPorID(Long I) {
        Consulta ea = new Consulta();
        EntityManagerFactory emf= FabricaConexao.getConexao();
        EntityManager em = emf.createEntityManager();
        TypedQuery<Consulta> query = em.createQuery("SELECT c FROM Equipamentos_Alienados c where c.id="+I,Consulta.class);
        List<Consulta> lista = query.getResultList();
        em.close();
        emf.close();
        if(lista.size() > 0)
            ea= (Consulta) lista.get(0);
        return ea;
    }
}
