package br.femass.ds2.N2.dao;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class FabricaConexao {
    
    public static EntityManagerFactory getConexao(){
             EntityManagerFactory emf = Persistence.createEntityManagerFactory("n2WEBPU");
             return emf;
         }        
}
