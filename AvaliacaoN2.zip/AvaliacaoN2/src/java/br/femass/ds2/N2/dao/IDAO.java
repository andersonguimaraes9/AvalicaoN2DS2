
package br.femass.ds2.N2.dao;
import java.util.List;

/**
 *
 * @author Anderson Guimaraes
 */
public interface IDAO {
    public void cadastrar(Object o);
    public void alterar(Object o);
    public void excluir(Object o);
    public List listar();
    
}
