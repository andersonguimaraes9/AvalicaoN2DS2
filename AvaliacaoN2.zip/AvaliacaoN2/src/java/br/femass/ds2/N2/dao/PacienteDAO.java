
package br.femass.ds2.N2.dao;

import br.femass.ds2.N2.modelo.Paciente;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;


/**
 *
 * @author Anderson
 */
public class PacienteDAO implements IDAO{

    @Override
    public void cadastrar(Object o) {
       Paciente c = (Paciente) o;       
        EntityManagerFactory emf= FabricaConexao.getConexao();
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(c);
        em.getTransaction().commit();
        em.close(); 
       
    }

    @Override
    public void alterar(Object o) {
         Paciente c = (Paciente) o;
         EntityManagerFactory emf= FabricaConexao.getConexao();        
        EntityManager em = emf.createEntityManager();
        Paciente cAux = em.find(Paciente.class, c.getId());
        if(cAux==null){
            try {            
                throw new Exception("Cliente não existe mais!");
            } catch (Exception ex) {
                Logger.getLogger(PacienteDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        em.getTransaction().begin();
        em.merge(c);
        em.getTransaction().commit();
        em.close(); 
    }

    @Override
    public void excluir(Object o) {
        Paciente c = (Paciente) o;
        EntityManagerFactory emf= FabricaConexao.getConexao();
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        c = em.find(Paciente.class, c.getId());
        em.remove(c);
        em.getTransaction().commit();
        em.close(); 
    }

    @Override
    public List listar() {
       EntityManagerFactory emf= FabricaConexao.getConexao();
        EntityManager em = emf.createEntityManager();
        TypedQuery<Paciente> query = em.createQuery("SELECT c FROM Paciente c",Paciente.class);
        List<Paciente> lista = query.getResultList();
        //for(Cliente cl:lista){
         //   System.out.println(cl);
        //}
        em.close();
        emf.close();
        return lista;
    }
    //Metodo para preecher combobox na guiEuipAlienados
    public static List<Paciente> listaDeCodigosEquip(){
         EntityManagerFactory emf= FabricaConexao.getConexao();
        EntityManager em = emf.createEntityManager();
        TypedQuery<Paciente> query = em.createQuery("SELECT c FROM Equipamentos c where c.status= 'ativo'",Paciente.class);
        List<Paciente> lista = query.getResultList();
        
        em.close();
        emf.close();
        return lista;
       
    }
    public Object listarPorID(Long I) {
        Paciente es = new Paciente();
        EntityManagerFactory emf= FabricaConexao.getConexao();
        EntityManager em = emf.createEntityManager();
        TypedQuery<Paciente> query = em.createQuery("SELECT c FROM Paciente c where c.id="+I,Paciente.class);
        List<Paciente> lista = query.getResultList();
        em.close();
        emf.close();
        if(lista.size() > 0)
            es= (Paciente) lista.get(0);
        return es;
    }
    public List listarPorFabricante(String fabric) {
        EntityManagerFactory emf= FabricaConexao.getConexao();
        EntityManager em = emf.createEntityManager();
        TypedQuery<Paciente> query = em.createQuery("SELECT c FROM Equipamentos c where c.fabricante= "+"'"+fabric+"'",Paciente.class);
        List<Paciente> lista = query.getResultList();
        
        em.close();
        emf.close();
        return lista;
    }
}
