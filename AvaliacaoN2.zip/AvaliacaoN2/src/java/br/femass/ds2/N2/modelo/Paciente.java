/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.femass.ds2.N2.modelo;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

/**
 *
 * @author Anderson Guimaraes
 */
@Entity
public class Paciente implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;
    private String endereco;
    private String celular;
    private String email;
    private String tiposanguinio;
    private String fatorrh;
    
    // relacionamento de um para um com equipamento alienados
    @OneToOne(mappedBy = "equipamento")
     private Consulta alienados; 
    // relacionamento de um para muitos substituicao_equipamentos 

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

  

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTiposanguinio() {
        return tiposanguinio;
    }

    public void setTiposanguinio(String tiposanguinio) {
        this.tiposanguinio = tiposanguinio;
    }

    public String getFatorrh() {
        return fatorrh;
    }

    public void setFatorrh(String fatorrh) {
        this.fatorrh = fatorrh;
    }

    public Consulta getAlienados() {
        return alienados;
    }

    public void setAlienados(Consulta alienados) {
        this.alienados = alienados;
    }
    

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Paciente)) {
            return false;
        }
        Paciente other = (Paciente) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return this.id+", "+this.nome+ ", "+ this.celular;
    }

    
    
}
